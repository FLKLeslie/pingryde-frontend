<!-- components/RideRequestCard.vue — Professional card with animations -->
<template>
  <div class="pr-card hover:border-pr-teal/25 hover:-translate-y-0.5 transition-all overflow-hidden" :class="{ 'border-pr-orange/40': isNew, 'border-pr-yellow/30': isSpecial }">

    <!-- NEW indicator strip at top -->
    <div v-if="isNew" class="flex items-center gap-1.5 px-3.5 py-1.5 bg-pr-orange/8 text-xs font-semibold text-pr-orange border-b border-pr-orange/15">
      <span class="w-1.5 h-1.5 rounded-full bg-pr-orange animate-live-pulse inline-block"></span>
      New request
    </div>

    <!-- Main content -->
    <div class="flex items-center justify-between p-3.5 gap-2.5">

      <!-- Left: passenger avatar + info -->
      <div class="flex items-center gap-2.5 min-w-0">
        <div class="w-10 h-10 rounded-full flex-shrink-0 bg-pr-teal/12 overflow-hidden flex items-center justify-center">
          <img v-if="passengerPhoto"
               :src="`http://localhost:5000${passengerPhoto}`"
               class="w-full h-full object-cover" />
          <span v-else class="text-xs font-bold text-pr-teal font-display">{{ passengerInitials }}</span>
        </div>
        <div class="min-w-0">
          <p class="text-sm font-semibold m-0 whitespace-nowrap overflow-hidden text-ellipsis">{{ passengerName }}</p>
          <p class="text-xs text-pr-muted m-0">{{ timeAgo }}</p>
        </div>
      </div>

      <!-- Right: ride type badge + expiry -->
      <div class="flex flex-col items-end gap-1 flex-shrink-0">
        <span class="text-xs font-semibold px-2.5 py-1 rounded-full" :class="[
          isSpecial ? 'text-pr-yellow bg-pr-yellow/12' : 
          request.rideType === 'bike' ? 'text-pr-orange bg-pr-orange/12' : 
          'text-pr-teal bg-pr-teal/12'
        ]">
          {{ typeLabel }}
        </span>
        <p v-if="expiresIn" class="text-xs text-pr-yellow m-0 font-semibold">
          ⏰ {{ expiresIn }}
        </p>
      </div>

    </div>

    <!-- Details row -->
    <div class="flex items-center gap-3 px-4 py-2.5 flex-wrap text-xs text-pr-muted">
      <span class="flex items-center gap-1">
        <span class="text-sm">📍</span>
        {{ request.region || 'Unknown region' }}
      </span>
      <span v-if="isSpecial" class="text-pr-yellow">
        📦 Special
      </span>
    </div>

    <!-- Special request description -->
    <p v-if="isSpecial && request.specialRequest?.description"
       class="m-0 mx-4 mb-2.5 text-xs text-pr-muted italic bg-pr-surface2 px-3 py-2 rounded-lg">
      "{{ request.specialRequest.description }}"
    </p>

    <!-- Accept button with animation -->
    <button @click="$emit('accept')" class="w-full px-4 py-3 border-t border-pr-border bg-transparent text-pr-teal text-sm font-semibold font-body cursor-pointer flex items-center justify-center gap-2 transition-colors hover:bg-pr-teal/8 active:bg-pr-teal/15 rounded-b-pr">
      <span class="text-base">✅</span>
      Accept Ride
    </button>

  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  request: { type: Object, required: true }
})
defineEmits(['accept'])

const passengerName = computed(() => {
  if (props.request.passengerId?.name) return props.request.passengerId.name
  if (props.request.passengerName)     return props.request.passengerName
  return 'Passenger'
})

const passengerPhoto = computed(() =>
  props.request.passengerId?.profilePhoto || null
)

const passengerInitials = computed(() =>
  passengerName.value.split(' ').map(n => n[0]).join('').toUpperCase().slice(0,2)
)

const isNew = computed(() => {
  if (!props.request.createdAt) return true
  return (Date.now() - new Date(props.request.createdAt)) < 3 * 60 * 1000
})

const isSpecial = computed(() => props.request.rideCategory === 'special')

const typeLabel = computed(() => {
  if (isSpecial.value) return '📦 Special'
  return props.request.rideType === 'bike' ? '🏍️ Bike' : '🚕 Taxi'
})

const typeBadgeClass = computed(() => ({
  'badge--bike':    props.request.rideType === 'bike',
  'badge--taxi':    props.request.rideType === 'taxi',
  'badge--special': isSpecial.value,
}))

// Expiry countdown
const expiresIn = computed(() => {
  if (!props.request.expiresAt) return null
  const remaining = Math.floor((new Date(props.request.expiresAt) - Date.now()) / 1000)
  if (remaining <= 0) return 'Expiring...'
  const m = Math.floor(remaining / 60)
  const s = remaining % 60
  return m > 0 ? `${m}m ${s}s left` : `${s}s left`
})

const timeAgo = computed(() => {
  if (!props.request.createdAt) return 'Just now'
  const mins = Math.floor((Date.now() - new Date(props.request.createdAt)) / 60000)
  if (mins < 1) return 'Just now'
  if (mins < 60) return `${mins}m ago`
  return `${Math.floor(mins/60)}h ago`
})
</script>

<style scoped>
/* Entry animation */
@keyframes rrcIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

.pr-card {
  animation: rrcIn 0.3s ease both;
}
</style>