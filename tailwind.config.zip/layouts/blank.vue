<!-- layouts/blank.vue
  Used by: index.vue, passenger/login.vue, driver/login.vue
  Shows a minimal header with logo only — user is not logged in.
-->
<template>
  <div class="flex flex-col min-h-screen">

    <!-- Minimal brand header -->
    <header class="sticky top-0 z-50 bg-pr-bg/96 backdrop-blur-2xl border-b border-white/7">
      <div class="max-w-pr mx-auto px-5 sm:px-6 lg:px-10 h-14 flex items-center justify-between">
        <NuxtLink to="/" class="flex items-center gap-2 no-underline">
          <div class="w-8 h-8 rounded-lg bg-pr-teal/12 border border-pr-teal/25 flex items-center justify-center text-sm">
            🚀
          </div>
          <span class="font-display text-lg font-black text-pr-teal">
            PingRyde
          </span>
        </NuxtLink>
        <span class="text-xs text-pr-muted">Cameroon 🇨🇲</span>
      </div>
    </header>

    <!-- Page content -->
    <main class="flex-1">
      <slot />
    </main>

  </div>
</template>