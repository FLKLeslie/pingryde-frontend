<!-- layouts/default.vue — App shell with top navbar and compact footer -->
<template>
  <div class="flex flex-col min-h-screen">

    <!-- ═══════════════ TOP NAVBAR ═══════════════ -->
    <header class="sticky top-0 z-50 bg-pr-bg/96 backdrop-blur-2xl border-b border-white/7">
      <div class="max-w-pr mx-auto px-4 h-14 flex items-center gap-2">

        <NuxtLink :to="userStore.isDriver ? '/driver/dashboard' : '/passenger/request'"
                  class="flex items-center gap-2 no-underline flex-shrink-0 mr-2">
          <div class="w-8 h-8 rounded-lg bg-pr-teal/12 border border-pr-teal/25 flex items-center justify-center text-sm">🚀</div>
          <span class="font-display text-lg font-black text-pr-teal">PingRyde</span>
        </NuxtLink>

        <!-- Passenger nav -->
        <nav v-if="userStore.isPassenger" class="flex items-center gap-0.5 flex-1 justify-center">
          <NuxtLink to="/passenger/request"  class="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg no-underline text-pr-muted text-xs font-medium transition-all hover:bg-white/5 hover:text-pr-text router-link-active:bg-pr-teal/10 router-link-active:text-pr-teal whitespace-nowrap"><span class="text-base leading-none">🚕</span><span class="hidden sm:inline">Request</span></NuxtLink>
          <NuxtLink to="/passenger/tracking" class="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg no-underline text-pr-muted text-xs font-medium transition-all hover:bg-white/5 hover:text-pr-text router-link-active:bg-pr-teal/10 router-link-active:text-pr-teal whitespace-nowrap"><span class="text-base leading-none">📍</span><span class="hidden sm:inline">Track</span></NuxtLink>
          <NuxtLink to="/passenger/rides"    class="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg no-underline text-pr-muted text-xs font-medium transition-all hover:bg-white/5 hover:text-pr-text router-link-active:bg-pr-teal/10 router-link-active:text-pr-teal whitespace-nowrap"><span class="text-base leading-none">🛣️</span><span class="hidden sm:inline">My Rides</span></NuxtLink>
        </nav>

        <!-- Driver nav -->
        <nav v-else-if="userStore.isDriver" class="flex items-center gap-0.5 flex-1 justify-center">
          <NuxtLink to="/driver/dashboard"  class="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg no-underline text-pr-muted text-xs font-medium transition-all hover:bg-white/5 hover:text-pr-text router-link-active:bg-pr-teal/10 router-link-active:text-pr-teal whitespace-nowrap"><span class="text-base leading-none">🏠</span><span class="hidden sm:inline">Home</span></NuxtLink>
          <NuxtLink to="/driver/requests"   class="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg no-underline text-pr-muted text-xs font-medium transition-all hover:bg-white/5 hover:text-pr-text router-link-active:bg-pr-teal/10 router-link-active:text-pr-teal whitespace-nowrap">
            <span class="text-base leading-none">🔔</span><span class="hidden sm:inline">Requests</span>
            <span v-if="rideStore.pendingRequests.length > 0" class="absolute top-1 right-1 w-4 h-4 rounded-full bg-pr-orange text-white text-xs font-bold flex items-center justify-center px-0.5 animate-live-pulse">
              {{ rideStore.pendingRequests.length }}
            </span>
          </NuxtLink>
          <NuxtLink to="/driver/map"        class="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg no-underline text-pr-muted text-xs font-medium transition-all hover:bg-white/5 hover:text-pr-text router-link-active:bg-pr-teal/10 router-link-active:text-pr-teal whitespace-nowrap"><span class="text-base leading-none">🗺️</span><span class="hidden sm:inline">Active</span></NuxtLink>
        </nav>

        <div class="flex items-center gap-2 ml-auto flex-shrink-0">
          <span v-if="userStore.region" class="text-xs text-pr-muted px-2.5 py-1 rounded-full border border-white/7 whitespace-nowrap bg-white/3 hidden sm:inline-block">📍 {{ userStore.region }}</span>
          <NuxtLink :to="userStore.isDriver ? '/driver/profile' : '/passenger/profile'"
                    class="w-9 h-9 rounded-full bg-pr-teal/15 text-pr-teal flex items-center justify-center font-bold text-sm font-display no-underline flex-shrink-0 overflow-hidden transition-all border border-pr-teal/20 hover:bg-pr-teal/25 hover:scale-105" :title="userStore.name + ' — Profile'">
            <img v-if="userStore.profilePhoto"
                 :src="`http://localhost:5000${userStore.profilePhoto}`"
                 class="w-full h-full object-cover" />
            <span v-else>{{ userStore.initials }}</span>
          </NuxtLink>
        </div>

      </div>
    </header>

    <!-- ═══════════════ CONTENT ═══════════════ -->
    <main class="flex-1 w-full"><slot /></main>

    <!-- ═══════════════ FOOTER ═══════════════ -->
    <footer class="bg-pr-surface border-t border-white/7 mt-auto">
      <div class="max-w-pr mx-auto px-4 py-4.5">
        <div class="flex items-center gap-2 flex-wrap mb-3">
          <span class="text-base">🚀</span>
          <span class="font-display text-sm font-bold text-pr-teal">PingRyde</span>
          <span class="text-pr-muted">—</span>
          <span class="text-xs text-pr-muted">Real-time ride coordination · Cameroon 🇨🇲</span>
        </div>
        <div class="flex items-center justify-between flex-wrap gap-2 pt-3 border-t border-white/5">
          <span class="text-xs text-pr-muted">© {{ year }} PingRyde. All rights reserved.</span>
          <div class="flex gap-4">
            <a href="#" class="text-xs text-pr-muted no-underline transition-colors hover:text-pr-teal">Privacy</a>
            <a href="#" class="text-xs text-pr-muted no-underline transition-colors hover:text-pr-teal">Terms</a>
            <a href="#" class="text-xs text-pr-muted no-underline transition-colors hover:text-pr-teal">Support</a>
          </div>
        </div>
      </div>
    </footer>

  </div>
</template>

<script setup>
import { useUserStore } from '~/store/user'
import { useRideStore } from '~/store/ride'
const userStore = useUserStore()
const rideStore = useRideStore()
const year      = new Date().getFullYear()
</script>

<style scoped>
/* Custom animation for notification dot pulse */
@keyframes notifPulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.15); }
}
</style>