<!-- pages/index.vue — LANDING PAGE
  ─────────────────────────────────────────────────────────────────
  This is the FIRST page every visitor sees.
  It must:
    1. Immediately communicate what PingRyde is
    2. Show the key value proposition (why it's better)
    3. Let people get started (choose passenger or driver)
    4. Look great on phones, tablets AND desktops
    5. Load fast — no heavy images or libraries

  SECTIONS:
    A. Hero           — headline, sub-headline, CTA, animated illustration
    B. How it works   — 4 steps showing the ride flow
    C. Why PingRyde   — 3 feature highlights
    D. Get started    — role chooser + action button
    E. Footer         — simple copyright line

  ANIMATIONS:
    • Hero elements fade up on load (CSS, no JS needed)
    • The "ping" pulse animation on the logo (CSS only)
    • The live map simulation — 3 dots moving closer together
      (CSS keyframes, no libraries, ~2KB)
    • All animations respect prefers-reduced-motion
-->
<template>
  <div class="w-full overflow-x-hidden">

    <!-- ══════════════════════════════════════════════════════════
         A.  HERO SECTION
    ════════════════════════════════════════════════════════════ -->
    <section class="min-h-[90vh] flex items-center px-5 sm:px-6 lg:px-10 py-16 relative overflow-hidden" style="background: radial-gradient(ellipse 70% 50% at 30% 50%, rgba(0,212,184,0.07) 0%, transparent 60%), radial-gradient(ellipse 50% 50% at 80% 60%, rgba(255,107,53,0.05) 0%, transparent 60%)">
      <div class="max-w-pr mx-auto w-full flex flex-col lg:flex-row gap-12 lg:gap-16 items-center">

        <!-- LEFT: Text content -->
        <div class="pr-animate-stagger lg:flex-1">

          <!-- Brand badge -->
          <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-pr-teal/30 bg-pr-teal/8 text-pr-teal text-xs font-semibold uppercase tracking-widest mb-5">
            <span class="w-1.5 h-1.5 rounded-full bg-pr-teal animate-live-pulse"></span>
            Live in Cameroon · Real-time
          </div>

          <!-- Headline -->
          <h1 class="text-4xl sm:text-5xl lg:text-6xl font-display font-black leading-tight mb-[18px]">
            Rides that <span class="text-pr-teal underline decoration-pr-teal/40 decoration-[3px] underline-offset-[6px]">find you</span><br>
            — not the other way around
          </h1>

          <!-- Sub-headline -->
          <p class="text-base text-pr-muted leading-[1.7] mb-8 max-w-[520px]">
            PingRyde connects passengers and drivers across Cameroon
            using live GPS tracking. No fixed addresses needed —
            both parties move toward each other in real time.
          </p>

          <!-- CTA buttons -->
          <div class="flex gap-3 flex-wrap mb-7">
            <button @click="scrollToGetStarted" class="pr-btn-primary inline-flex">
              Get Started Free
              <span class="group-hover:translate-x-1 transition-transform">→</span>
            </button>
            <button @click="scrollToHowItWorks" class="inline-flex items-center px-6 py-3 rounded-pr bg-transparent text-pr-muted text-sm font-medium border border-pr-border hover:border-pr-teal/30 hover:text-pr-text transition-all">
              See how it works
            </button>
          </div>

          <!-- Trust indicators -->
          <div class="flex gap-5 flex-wrap">
            <div class="flex items-center gap-1.5 text-sm text-pr-muted">
              <span class="text-base">⚡</span>
              <span>Real-time GPS</span>
            </div>
            <div class="flex items-center gap-1.5 text-sm text-pr-muted">
              <span class="text-base">🇨🇲</span>
              <span>All 10 regions</span>
            </div>
            <div class="flex items-center gap-1.5 text-sm text-pr-muted">
              <span class="text-base">🔒</span>
              <span>Secure & private</span>
            </div>
          </div>
        </div>

        <!-- RIGHT: Live map animation -->
        <div class="w-full max-w-xs lg:flex-1 flex flex-col gap-3">
          <div class="w-full h-72 sm:h-80 bg-pr-surface border border-pr-border rounded-3xl relative overflow-hidden">

            <!-- Grid lines (like a real map) -->
            <div class="absolute inset-0">
              <div class="absolute w-full h-px bg-white/4" style="top:25%"></div>
              <div class="absolute w-full h-px bg-white/4" style="top:50%"></div>
              <div class="absolute w-full h-px bg-white/4" style="top:75%"></div>
              <div class="absolute h-full w-px bg-white/4" style="left:25%"></div>
              <div class="absolute h-full w-px bg-white/4" style="left:50%"></div>
              <div class="absolute h-full w-px bg-white/4" style="left:75%"></div>
            </div>

            <!-- Road lines -->
            <div class="absolute w-full h-2 bg-white/8 left-0" style="top:50%"></div>
            <div class="absolute h-full w-2 bg-white/8 top-0" style="left:38%"></div>

            <!-- PASSENGER marker — moves from left toward centre -->
            <div class="absolute top-1/2 -translate-y-1/2 flex items-center justify-center" style="left:15%; animation: passengerMove 4s ease-in-out infinite">
              <div class="absolute inset-[-8px] border-2 border-pr-teal/50 rounded-full animate-ping opacity-75" style="animation: markerPulse 2s ease-out infinite"></div>
              <div class="w-9 h-9 rounded-full bg-pr-teal border-2 border-pr-bg flex items-center justify-center box-shadow: 0 2px 12px rgba(0,212,184,0.4); relative z-10">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="7" r="4" fill="#1E2A32"/>
                  <path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8" fill="#1E2A32"/>
                </svg>
              </div>
            </div>

            <!-- DRIVER marker — moves from right toward centre -->
            <div class="absolute top-1/2 -translate-y-1/2 flex items-center justify-center" style="right:15%; animation: driverMove 4s ease-in-out infinite">
              <div class="w-9 h-7 rounded-lg bg-pr-orange border-2 border-pr-bg flex items-center justify-center shadow" style="box-shadow: 0 2px 12px rgba(255,107,53,0.4)">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <rect x="2" y="9" width="20" height="9" rx="2" fill="#1E2A32"/>
                  <rect x="5" y="5" width="14" height="6" rx="2" fill="#1E2A32"/>
                  <circle cx="6.5"  cy="18" r="2" fill="#1E2A32" opacity="0.6"/>
                  <circle cx="17.5" cy="18" r="2" fill="#1E2A32" opacity="0.6"/>
                </svg>
              </div>
            </div>

            <!-- Dashed connection line between the two -->
            <div class="absolute top-1/2 -translate-y-1/2" style="left:30%; right:30%; height:2px; background: repeating-linear-gradient(90deg, rgba(255,255,255,0.2) 0px, rgba(255,255,255,0.2) 6px, transparent 6px, transparent 12px); animation: lineAppear 4s ease-in-out infinite"></div>

            <!-- Status overlay -->
            <div class="absolute top-3.5 left-3.5 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-pr-bg/85 border border-pr-border backdrop-blur text-xs text-pr-text">
              <div class="w-2 h-2 rounded-full bg-pr-teal animate-live-pulse"></div>
              <span>2 drivers nearby</span>
            </div>

            <!-- ETA chip -->
            <div class="absolute bottom-3.5 right-3.5 px-3 py-1.5 rounded-full bg-pr-orange/15 border border-pr-orange/30 text-pr-orange text-xs font-semibold">~4 min away</div>

          </div>

          <!-- Caption below animation -->
          <p class="text-xs text-pr-muted text-center">
            Live simulation — passenger 🟢 and driver 🟠 moving toward each other
          </p>
        </div>

      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════════
         B.  HOW IT WORKS
    ════════════════════════════════════════════════════════════ -->
    <section id="how-it-works" class="py-20 bg-pr-surface">
      <div class="max-w-pr mx-auto w-full px-4 sm:px-6 lg:px-10">

        <div class="text-center mb-12">
          <p class="text-xs font-bold uppercase tracking-widest text-pr-teal mb-2.5">Simple. Fast. Reliable.</p>
          <h2 class="text-2xl sm:text-3xl lg:text-4xl font-display font-black mb-3.5">How PingRyde works</h2>
          <p class="text-base text-pr-muted max-w-2xl mx-auto leading-[1.7]">
            Four steps from "I need a ride" to "I'm on my way" —
            all happening in under 30 seconds.
          </p>
        </div>

        <div class="pr-animate-stagger grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div v-for="step in steps" :key="step.n" class="pr-card hover:border-pr-teal/30 hover:-translate-y-0.5 transition-all cursor-pointer">
            <div class="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold mb-3.5" :style="`background: ${step.bg}; color: ${step.color}`">
              {{ step.n }}
            </div>
            <div class="text-3xl mb-2.5">{{ step.icon }}</div>
            <h3 class="text-base font-bold mb-2">{{ step.title }}</h3>
            <p class="text-sm text-pr-muted leading-[1.65]">{{ step.desc }}</p>
          </div>
        </div>

      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════════
         C.  WHY PINGRYDE — Feature highlights
    ════════════════════════════════════════════════════════════ -->
    <section class="py-20">
      <div class="max-w-pr mx-auto w-full px-4 sm:px-6 lg:px-10">

        <div class="text-center mb-12">
          <p class="text-xs font-bold uppercase tracking-widest text-pr-teal mb-2.5">Built for Cameroon</p>
          <h2 class="text-2xl sm:text-3xl lg:text-4xl font-display font-black mb-3.5">Why choose PingRyde?</h2>
        </div>

        <div class="pr-animate-stagger grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          <div v-for="feat in features" :key="feat.title" class="bg-pr-surface2 border border-pr-border rounded-2xl p-6 hover:border-pr-teal/25 hover:-translate-y-0.5 transition-all">
            <div class="w-12 h-12 rounded-2xl flex items-center justify-center mb-4" :style="`background: ${feat.bg}`">
              <span class="text-2xl">{{ feat.icon }}</span>
            </div>
            <h3 class="text-base font-bold mb-2">{{ feat.title }}</h3>
            <p class="text-sm text-pr-muted leading-[1.65]">{{ feat.desc }}</p>
          </div>
        </div>

      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════════
         D.  GET STARTED — Role chooser
    ════════════════════════════════════════════════════════════ -->
    <section id="get-started" class="py-20 bg-pr-surface">
      <div class="max-w-2xl mx-auto w-full px-4 sm:px-6 lg:px-10">

        <div class="text-center mb-12">
          <p class="text-xs font-bold uppercase tracking-widest text-pr-teal mb-2.5">Ready to go?</p>
          <h2 class="text-2xl sm:text-3xl lg:text-4xl font-display font-black mb-3.5">Join PingRyde today</h2>
          <p class="text-base text-pr-muted">Choose how you want to use the app. It takes less than 2 minutes.</p>
        </div>

        <!-- Role selection cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-7">
          <button
            v-for="role in roles"
            :key="role.value"
            @click="selected = role.value"
            class="relative bg-pr-bg border-2 rounded-2xl p-6 text-left hover:-translate-y-0.5 transition-all"
            :class="selected === role.value ? 'border-2' : 'border-pr-border'"
            :style="selected === role.value ? `border-color: ${role.color}; background: ${role.bg}` : ''"
          >
            <div class="w-13 h-13 rounded-2xl flex items-center justify-center mb-3.5" :style="`background: ${role.iconBg}`">
              <span class="text-3xl">{{ role.icon }}</span>
            </div>
            <div class="mb-4">
              <h3 class="text-lg font-bold mb-1">{{ role.label }}</h3>
              <p class="text-xs text-pr-muted uppercase tracking-widest">{{ role.sub }}</p>
            </div>
            <ul class="space-y-1.5">
              <li v-for="p in role.perks" :key="p" class="text-sm text-pr-muted flex items-center gap-2">
                <span class="text-pr-teal font-bold text-xs">✓</span> {{ p }}
              </li>
            </ul>
            <!-- Selection indicator -->
            <div v-if="selected === role.value"
                 class="absolute top-3.5 right-3.5 px-2.5 py-1 rounded-full text-xs font-bold"
                 :style="`background: ${role.color}; color: #1E2A32`">
              Selected ✓
            </div>
          </button>
        </div>

        <!-- CTA button appears after role selection -->
        <Transition name="rise">
          <div v-if="selected" class="flex flex-col items-center gap-2.5">
            <button @click="proceed" class="w-full pr-btn-primary">
              Continue as {{ selected === 'passenger' ? 'Passenger' : 'Driver' }}
              <span class="transition-transform group-hover:translate-x-1">→</span>
            </button>
            <p class="text-xs text-pr-muted">Free to join · No credit card needed</p>
          </div>
        </Transition>

      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════════
         E.  LANDING FOOTER
    ════════════════════════════════════════════════════════════ -->
    <footer class="border-t border-pr-border bg-pr-surface">
      <div class="max-w-pr mx-auto w-full px-4 sm:px-6 lg:px-10 py-5 flex justify-between flex-wrap gap-2 text-xs text-pr-muted">
        <span>🚀 PingRyde — Made for Cameroon 🇨🇲</span>
        <span>© {{ year }} · All rights reserved</span>
      </div>
    </footer>

  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

// This page uses the "blank" layout (simple header + no auth nav)
definePageMeta({ layout: 'blank' })

const router   = useRouter()
const selected = ref('')         // 'passenger' | 'driver'
const year     = new Date().getFullYear()

// Scroll helpers — smooth scroll to sections
const scrollToGetStarted  = () => document.getElementById('get-started')?.scrollIntoView({ behavior:'smooth' })
const scrollToHowItWorks  = () => document.getElementById('how-it-works')?.scrollIntoView({ behavior:'smooth' })

// Navigate to the appropriate login page
const proceed = () => router.push(selected.value === 'passenger' ? '/passenger/login' : '/driver/login')

// ── Content data ──────────────────────────────────────────────────

const steps = [
  { n:1, icon:'📡', title:'Passenger pings a ride',    color:'#00D4B8', bg:'rgba(0,212,184,0.12)',
    desc:'Open the app, choose taxi or moto, and tap "Ping a Ride". Your GPS location is shared automatically — no address needed.' },
  { n:2, icon:'🔔', title:'Nearby drivers are alerted', color:'#FF6B35', bg:'rgba(255,107,53,0.12)',
    desc:'The 5 nearest online drivers receive an instant push notification through the app. First to accept wins.' },
  { n:3, icon:'🗺️', title:'Live tracking begins',        color:'#F0C040', bg:'rgba(240,192,64,0.12)',
    desc:'Once accepted, both parties see each other on a live map. GPS updates every 2 seconds. Both move toward each other.' },
  { n:4, icon:'✅', title:'Ride complete',               color:'#00D4B8', bg:'rgba(0,212,184,0.12)',
    desc:'Driver marks the ride complete in-app. Both return to their home screens, ready for the next ride.' },
]

const features = [
  { icon:'📍', title:'No fixed addresses',   bg:'rgba(0,212,184,0.08)',
    desc:'Works in any neighbourhood, market, or bush path in Cameroon. Share your live location instead of describing where you are.' },
  { icon:'⚡', title:'Instant matching',      bg:'rgba(255,107,53,0.08)',
    desc:'Socket.io powers real-time notifications. Drivers receive ride alerts the instant a passenger pings — no refreshing needed.' },
  { icon:'🗺️', title:'Live bidirectional GPS', bg:'rgba(240,192,64,0.08)',
    desc:'Both driver and passenger track each other simultaneously. Watch the markers move in real time — like a live radar.' },
  { icon:'🔕', title:'No more phone calls',   bg:'rgba(0,212,184,0.08)',
    desc:'Eliminate the back-and-forth calls of "where are you?". The map shows exactly where both parties are at all times.' },
  { icon:'🇨🇲', title:'Built for Cameroon',  bg:'rgba(255,107,53,0.08)',
    desc:'Covers all 10 regions. Region is auto-detected from GPS. Ride requests are filtered by proximity and region.' },
  { icon:'🔒', title:'Private ride sessions', bg:'rgba(240,192,64,0.08)',
    desc:'Each accepted ride gets a private Socket.io room. Only driver and passenger share location — nobody else can see.' },
]

const roles = [
  {
    value:   'passenger',
    label:   'I need a ride',
    sub:     'Passenger',
    icon:    '🧍',
    color:   '#00D4B8',
    bg:      'rgba(0,212,184,0.06)',
    iconBg:  'rgba(0,212,184,0.12)',
    perks:   ['Request taxi or moto', 'Live map tracking', 'See driver en route'],
  },
  {
    value:   'driver',
    label:   'I give rides',
    sub:     'Driver',
    icon:    '🚕',
    color:   '#FF6B35',
    bg:      'rgba(255,107,53,0.06)',
    iconBg:  'rgba(255,107,53,0.12)',
    perks:   ['Get instant ride alerts', 'Go online / offline freely', 'Earn on your schedule'],
  },
]
</script>

<style scoped>
/* Custom animations for landing page that Tailwind can't generate */

@keyframes passengerMove {
  0%         { left: 15%; }
  45%, 55%   { left: 43%; }
  100%       { left: 15%; }
}

@keyframes driverMove {
  0%         { right: 15%; }
  45%, 55%   { right: 48%; }
  100%       { right: 15%; }
}

@keyframes markerPulse {
  0%   { transform: scale(0.8); opacity: 1; }
  100% { transform: scale(2); opacity: 0; }
}

@keyframes lineAppear {
  0%, 20%     { opacity: 0; }
  40%, 60%    { opacity: 1; }
  80%, 100%   { opacity: 0; }
}

/* Rise transition for the CTA button appearing */
.rise-enter-active {
  transition: all 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.rise-enter-from {
  opacity: 0;
  transform: translateY(20px) scale(0.95);
}
</style>