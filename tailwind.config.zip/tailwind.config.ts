// tailwind.config.ts
import type { Config } from 'tailwindcss'

export default {
  content: [
    './components/**/*.{vue,js,ts}',
    './layouts/**/*.vue',
    './pages/**/*.vue',
    './plugins/**/*.{js,ts}',
    './app.vue',
  ],
  theme: {
    extend: {
      colors: {
        'pr': {
          'teal':      '#00D4B8',   /* Primary */
          'orange':    '#FF6B35',   /* Secondary */
          'yellow':    '#F0C040',   /* Warning/Pending */
          'red':       '#FF4747',   /* Error/Cancel */
          'bg':        '#1E2A32',   /* Main background */
          'surface':   '#243340',   /* Cards/panels */
          'surface2':  '#2C3E4C',   /* Inputs/elevated */
          'text':      '#FFFFFF',   /* Main text */
          'muted':     '#8FA3B1',   /* Secondary text */
          'border':    'rgba(255,255,255,0.08)',
        },
      },
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        body:    ['DM Sans', 'sans-serif'],
      },
      spacing: {
        'px-responsive': 'var(--pr-px, 16px)',
        'py-responsive': 'var(--pr-py, 20px)',
      },
      maxWidth: {
        'pr': '1100px',
      },
      borderRadius: {
        'pr': '12px',
        'pr-sm': '8px',
        'pr-xs': '6px',
      },
      animation: {
        'live-pulse': 'livePulse 2.5s ease-in-out infinite',
        'fade-up': 'prFadeUp 0.3s ease both',
        'pr-spin': 'prSpin 0.8s linear infinite',
      },
      keyframes: {
        'livePulse': {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '0.5', transform: 'scale(1.3)' },
        },
        'prFadeUp': {
          'from': { opacity: '0', transform: 'translateY(12px)' },
          'to': { opacity: '1', transform: 'translateY(0)' },
        },
        'prSpin': {
          'to': { transform: 'rotate(360deg)' },
        },
      },
    },
  },
  plugins: [],
} satisfies Config